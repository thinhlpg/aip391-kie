# -*- coding: utf-8 -*-
# @Author: Wenwen Yu
# @Created Time: 7/8/2020 9:34 PM

Entities_list = [
    'SELLER',
    'ADDRESS',
    'TIMESTAMP',
    'TOTAL_COST'
]
#
# Entities_list = ['VAT_amount', 'VAT_amount_val', 'VAT_rate', 'VAT_rate_val', 'account_no', 'address', 'address_val',
#                  'amount_in_words', 'amount_in_words_val', 'bank', 'buyer', 'company_name', 'company_name_val', 'date',
#                  'exchange_rate', 'exchange_rate_val', 'form', 'form_val', 'grand_total', 'grand_total_val', 'no',
#                  'no_val', 'seller', 'serial', 'serial_val', 'tax_code', 'tax_code_val', 'total', 'total_val',
#                  'website']

# Entities_list = [
#     "ticket_num",
#     "starting_station",
#     "train_num",
#     "destination_station",
#     "date",
#     "ticket_rates",
#     "seat_category",
#     "name"
# ]
