python test.py --checkpoint /home/cuongnd/PycharmProjects/aicr/mc_ocr/key_info_extraction/PICK/saved/models/PICK_Default/test_0111_141716/model_best.pth
                --boxes_transcripts /data20.04/data/MC_OCR/output_results/key_info_extraction/public_test_pick/bboxes_and_transcripts \
               --images_path /data20.04/data/MC_OCR/output_results/key_info_extraction/public_test_pick/images
               --output_folder /data20.04/data/MC_OCR/output_results/key_info_extraction/public_test_pick/output \
               --gpu 0 --batch_size 1